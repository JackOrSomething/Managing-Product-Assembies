CREATE DATABASE  IF NOT EXISTS `prod_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `prod_db`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: prod_db
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assembly`
--

DROP TABLE IF EXISTS `assembly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assembly` (
  `assembly_ParentComponent` char(7) NOT NULL,
  `assembly_component` char(7) NOT NULL,
  `assembly_relationshipType` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`assembly_ParentComponent`,`assembly_component`),
  KEY `ASSEMBLYCHILD_RESPONSIVPART_FK1` (`assembly_component`),
  CONSTRAINT `ASSEMBLY_RESPONSIVPART_FK` FOREIGN KEY (`assembly_ParentComponent`) REFERENCES `responsivpart` (`responsivpart_Id`),
  CONSTRAINT `ASSEMBLYCHILD_RESPONSIVPART_FK1` FOREIGN KEY (`assembly_component`) REFERENCES `responsivpart` (`responsivpart_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `document_Id` char(7) NOT NULL,
  `part_Id` char(7) NOT NULL,
  `document_Type` varchar(32) NOT NULL,
  `document_Name` varchar(128) NOT NULL,
  `document_Desc` varchar(256) DEFAULT NULL,
  `document_Data` mediumblob NOT NULL,
  `document_URL` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`document_Id`),
  KEY `DOCUMENT_PART_FK` (`part_Id`),
  CONSTRAINT `DOCUMENT_PART_FK` FOREIGN KEY (`part_Id`) REFERENCES `part` (`part_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `part`
--

DROP TABLE IF EXISTS `part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `part` (
  `vendor_Id` char(7) NOT NULL,
  `part_Id` char(7) NOT NULL,
  `part_AuthorisationTerms` varchar(254) NOT NULL,
  `part_Brand` varchar(254) DEFAULT NULL,
  `part_EndOfLife` date DEFAULT NULL,
  `part_Group` varchar(254) DEFAULT NULL,
  `part_Language` varchar(254) DEFAULT NULL,
  `part_Media` varchar(254) DEFAULT NULL,
  `part_Name` varchar(512) NOT NULL,
  `part_Platform` varchar(128) DEFAULT NULL,
  `part_ProgramCode` varchar(128) DEFAULT NULL,
  `part_SubGroup` varchar(128) DEFAULT NULL,
  `part_Version` varchar(128) DEFAULT NULL,
  `part_VendorPartNumber` varchar(7) NOT NULL,
  `part_VendorPartId` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`part_Id`),
  KEY `PART_VENDOR_FK` (`vendor_Id`),
  CONSTRAINT `PART_VENDOR_FK` FOREIGN KEY (`vendor_Id`) REFERENCES `vendor` (`vendor_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `part_BEFORE_INSERT` BEFORE INSERT ON `part` FOR EACH ROW BEGIN
	IF (SELECT UPPER(vendor_Id) FROM PROD_DB.VENDOR WHERE UPPER(vendor_Name) = 'RESPONSIV') LIKE @vendor_id THEN
		SET @part_Id = CONCAT(VENDOR_ID , 'PLACEHOLDER');
		SET @part_VendorPartNumber = 'PLACEHOLDER';
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `partnumber`
--

DROP TABLE IF EXISTS `partnumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partnumber` (
  `LASTNUM` int NOT NULL,
  `PREFIX` char(2) NOT NULL,
  `PARTTYPE` varchar(32) NOT NULL,
  KEY `idx_partnumber_PARTTYPE` (`PARTTYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `price`
--

DROP TABLE IF EXISTS `price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price` (
  `part_Id` char(7) NOT NULL,
  `price_BandName` varchar(3) NOT NULL,
  `price_RangeMin` int NOT NULL,
  `price_RangeMax` int NOT NULL,
  `price_Price` decimal(10,0) NOT NULL,
  `price_BookId` varchar(512) NOT NULL,
  `price_BrandFamily` varchar(128) DEFAULT NULL,
  `price_ChargeUnit` varchar(128) NOT NULL,
  `price_Currency` varchar(128) NOT NULL,
  `price_DateAdded` date NOT NULL,
  `price_EndDate` date NOT NULL,
  `price_Expired` smallint NOT NULL,
  `price_RenewalModel` varchar(128) DEFAULT NULL,
  `price_StartDate` date NOT NULL,
  `price_TierModel` varchar(128) NOT NULL,
  `price_SearchTags` varchar(999) DEFAULT NULL,
  PRIMARY KEY (`part_Id`,`price_BandName`,`price_RangeMin`,`price_RangeMax`),
  CONSTRAINT `PRICE_PART_FK` FOREIGN KEY (`part_Id`) REFERENCES `part` (`part_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `responsivpart`
--

DROP TABLE IF EXISTS `responsivpart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `responsivpart` (
  `responsivpart_Id` char(7) NOT NULL,
  `part_Id` char(7) NOT NULL,
  `responsivpart_Type` varchar(32) NOT NULL,
  `responsivpart_ConditionNumber` varchar(5) NOT NULL,
  `responsivpart_ShortName` varchar(128) NOT NULL,
  `responsivpart_ResponsibleParty` varchar(128) NOT NULL,
  `responsivPart_StorageLocation` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`responsivpart_Id`),
  KEY `RESPONSIVPART_PART_FK` (`part_Id`),
  CONSTRAINT `RESPONSIVPART_PART_FK` FOREIGN KEY (`part_Id`) REFERENCES `part` (`part_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `step_pricing`
--

DROP TABLE IF EXISTS `step_pricing`;
/*!50001 DROP VIEW IF EXISTS `step_pricing`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `step_pricing` AS SELECT 
 1 AS `part_id`,
 1 AS `price_rangeMin`,
 1 AS `price_rangeMax`,
 1 AS `price_bandName`,
 1 AS `Unitprice`,
 1 AS `rangeTotal`,
 1 AS `previousTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendor` (
  `vendor_Id` char(7) NOT NULL,
  `vendor_Name` varchar(128) NOT NULL,
  `vendor_Type` varchar(128) NOT NULL,
  `vendor_PriceBookSource` varchar(254) NOT NULL,
  `vendor_PriceBookLocation` varchar(999) DEFAULT NULL,
  PRIMARY KEY (`vendor_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'prod_db'
--

--
-- Dumping routines for database 'prod_db'
--
/*!50003 DROP FUNCTION IF EXISTS `BASETODEC` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `BASETODEC`(val varchar(20), baseInt bigint) RETURNS bigint
    DETERMINISTIC
BEGIN
	DECLARE alldigits varchar(255) ;
	declare val2 varchar(20);
	declare answer DECIMAL;
	declare currectChar char(1);

	Set alldigits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	Set val2 = concat(val,' ');
	Set answer = 0;

	while Length(val2) > 1 DO
		set currectChar = LEFT(val2,1);
		set val2 = RIGHT(val2,(LENGTH(val2) - 1));
		set answer = answer + (LOCATE(currectChar,alldigits)-1) * power(baseInt,(LENGTH(val2)-1));
	END while;
	RETURN answer; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `CASTTOBASE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `CASTTOBASE`(val BigInt, baseInt Int) RETURNS varchar(63) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	Declare answer varchar(63);
	Declare alldigits varchar(36);
	Declare val2 DECIMAL;
	
	Set alldigits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	Set answer = '';
	set val2 = val;
    
	If baseInt< 2 or baseInt> 36 THEN
		 Return Null;
	End If;
    
	If val<=0 THEN
		Return '0';
	End If;
	
	While val2 >= 1 do
		Set answer = concat(Substring(alldigits,MOD(val2,baseInt) + 1,1), answer);
		Set val2 = floor(val2 / baseInt);
	END While;
	RETURN answer; 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GETNEXTPARTID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `GETNEXTPARTID`(Type varchar(45)) RETURNS varchar(7) CHARSET utf8mb4
    READS SQL DATA
BEGIN
	DECLARE X INTEGER;
	DECLARE CheckBit Char(1);
	DECLARE MidBit Char(4);
	DECLARE Prefix Char(2);

	SET X = (select LASTNUM FROM PROD_DB.PARTNUMBER WHERE UPPER(PARTTYPE) = UPPER(Type) limit 1);
	SET Prefix = 'RA';
	Set MidBit = concat(REPEAT('0',(4-LENGTH(PROD_DB.CASTTOBASE(X,33)))) , PROD_DB.CASTTOBASE(X,33));
	SET CheckBit = PROD_DB.CASTTOBASE(MOD(PROD_DB.BASETODEC(concat(Prefix,MidBit),33),31),33);
	RETURN concat(Prefix,MidBit,CheckBit);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `UPDATEPARTNUM` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `UPDATEPARTNUM`(INPUTTYPE varchar(50)) RETURNS int
    DETERMINISTIC
BEGIN
	UPDATE PROD_DB.PARTNUMBER
    SET LASTNUM = LASTNUM + 1
    WHERE UPPER(PARTTYPE) like UPPER(INPUTTYPE);
RETURN NULL;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Full Unpack` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Full Unpack`(respid varchar(7))
BEGIN
	with recursive Assembly_Tree(Assembly_Child,Assembly_Parent,Depth,ROUTE) as 
		(select assembly_component as Assembly_Child,assembly_ParentComponent as Assembly_Parent, 1 as Depth,CAST(assembly_ParentComponent as CHAR(140)) as ROUTE FROM
			PROD_DB.Assembly as ROOT
			where ROOT.assembly_ParentComponent LIKE respid
			Union All 
			Select Child.assembly_component,Child.assembly_ParentComponent ,Depth + 1, concat(ROUTE , '>' , Child.assembly_ParentComponent)
			from Assembly_Tree Parent, PROD_DB.Assembly Child 
			Where Parent.Assembly_Child = Child.assembly_ParentComponent
			)
			select responsivpart_Id,Assembly_Tree.Assembly_Parent as RESPONSIVPART_PARENT,part_Id,responsivpart_Type,responsivpart_ConditionNumber,responsivpart_ResponsibleParty,responsivpart_ShortName,responsivPart_StorageLocation,0 AS Depth, responsivpart_Id as ROUTE
			from PROD_DB.RESPONSIVPART 
			left join Assembly_Tree
			on PROD_DB.RESPONSIVPART.responsivpart_Id = Assembly_Tree.Assembly_Child
			where responsivpart_Id LIKE respid
			union
			select responsivpart_Id,Assembly_Tree.Assembly_Parent as RESPONSIVPART_PARENT,part_Id,responsivpart_Type,responsivpart_ConditionNumber,responsivpart_ResponsibleParty,responsivpart_ShortName,responsivPart_StorageLocation,Assembly_Tree.Depth, concat(Assembly_Tree.ROUTE , '>' ,responsivpart_Id) as ROUTE
			from PROD_DB.RESPONSIVPART 
			join Assembly_Tree
			on PROD_DB.RESPONSIVPART.responsivpart_Id = Assembly_Tree.Assembly_Child
			WHERE responsivpart_Id IN (SELECT Assembly_Child 
			from assembly_tree)
			ORDER BY ROUTE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getQuantityPrice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getQuantityPrice`(qty int, id char(7), band varchar(2))
BEGIN
	select part_id, price_bandName, previousTotal, price_rangeMin, unitPrice, qty, previousTotal + unitPrice*(qty-(price_rangeMin-1)) totalPrice from step_pricing where part_id=id and price_rangeMin <= qty and price_rangeMax >= qty and price_bandName = band;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Unpack` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Unpack`(respid varchar(7))
BEGIN
	with recursive assembly_tree(Assembly_Child,Assembly_Parent,Depth) as 
		(Select assembly_component as Assembly_Child,assembly_ParentComponent as Assembly_Parent, 1 as Depth
		 	from PROD_DB.Assembly as ROOT
			where ROOT.assembly_ParentComponent LIKE respid
			Union All 
			Select Child.assembly_component,Child.assembly_ParentComponent ,Depth + 1
			from Assembly_Tree Parent, PROD_DB.Assembly Child 
			Where Parent.Assembly_Child = Child.assembly_ParentComponent
			)
			select responsivpart_Id,Assembly_Tree.Assembly_Parent as RESPONSIVPART_PARENT,part_Id,responsivpart_Type,responsivpart_ConditionNumber,responsivpart_ResponsibleParty,responsivpart_ShortName,responsivPart_StorageLocation,0 AS Depth
			from PROD_DB.RESPONSIVPART 
			left join Assembly_Tree
			on PROD_DB.RESPONSIVPART.responsivpart_Id = Assembly_Tree.Assembly_Child
			where responsivpart_Id LIKE respid
			union
			select responsivpart_Id,Assembly_Tree.Assembly_Parent as RESPONSIVPART_PARENT,part_Id,responsivpart_Type,responsivpart_ConditionNumber,responsivpart_ResponsibleParty,responsivpart_ShortName,responsivPart_StorageLocation,Assembly_Tree.Depth 
			from PROD_DB.RESPONSIVPART 
			join Assembly_Tree
			on PROD_DB.RESPONSIVPART.responsivpart_Id = Assembly_Tree.Assembly_Child
			WHERE responsivpart_Id IN (SELECT Assembly_Child 
			from assembly_tree);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UPDATEPARTNUM` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UPDATEPARTNUM`(INPUTTYPE varchar(50))
BEGIN
    UPDATE PROD_DB.PARTNUMBER
    SET LASTNUM = LASTNUM + 1
    WHERE UPPER(PARTTYPE) like UPPER(INPUTTYPE);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `step_pricing`
--

/*!50001 DROP VIEW IF EXISTS `step_pricing`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `step_pricing` AS with recursive `pricing` as (select `root`.`part_Id` AS `part_id`,`root`.`price_RangeMin` AS `price_rangeMin`,`root`.`price_RangeMax` AS `price_rangeMax`,`root`.`price_BandName` AS `price_bandName`,`root`.`price_Price` AS `unitprice`,((`root`.`price_RangeMax` - (`root`.`price_RangeMin` - 1)) * `root`.`price_Price`) AS `rangeTotal` from `price` `root`) select `b`.`part_id` AS `part_id`,`b`.`price_rangeMin` AS `price_rangeMin`,`b`.`price_rangeMax` AS `price_rangeMax`,`b`.`price_bandName` AS `price_bandName`,`b`.`unitprice` AS `Unitprice`,`b`.`rangeTotal` AS `rangeTotal`,(case when (((select sum(`a`.`rangeTotal`) from `pricing` `a` where ((`b`.`part_id` = `a`.`part_id`) and (`b`.`price_bandName` = `a`.`price_bandName`) and (`b`.`price_rangeMax` > `a`.`price_rangeMin`))) - `b`.`rangeTotal`) is null) then 0 else ((select sum(`a`.`rangeTotal`) from `pricing` `a` where ((`b`.`part_id` = `a`.`part_id`) and (`b`.`price_bandName` = `a`.`price_bandName`) and (`b`.`price_rangeMax` > `a`.`price_rangeMin`))) - `b`.`rangeTotal`) end) AS `previousTotal` from `pricing` `b` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-06 23:52:47
